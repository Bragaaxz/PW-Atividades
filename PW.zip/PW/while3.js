
        soma = 1;
        i = 1;
        while (i <= 100 )	{
            i += 1;
            soma += i;
        console.log(soma);  	
        }
        