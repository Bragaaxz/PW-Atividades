
		 let id = 9
	// switch case
		switch (id) {
	// Dente de Leite	
		case 6: 
			console.log("Dente de leite");
				break;
	// Junior			
		case 7:
			console.log("Junior");
				break;
	// Junior Max			
		case 8:
			console.log("Junior Max");
				break;
	// Junior Master			
		case 9:
			console.log("Junior Master");
				break;
	// Master			
		case 10:
			console.log("Master");
				break;
	// Nao aceitamos			
		default:
			console.log("Nao aceitamos pessoas com essa idade.");
		}
	