    
	let idade = 16
	if (idade <10) {
		console.log ("nao ta podendo")
	} else if (idade <18)
	{
		console.log ("ta podendo")
	}else if (idade <60) {
		console.log ("ja pode demais")
	}else {
		console.log ("ta fazendo oq da vida")
	
}
