let i=2;
	while ( i <=200) {
		console.log(i);
	i +=2;	
    }