
	let	m = 7
	
	let	d = 3
	// Switch case
		switch (m) {
	// capricornio e Aquario
		case 1:
				if (d <=20 )
					console.log("Capric�rnio");
				else
                console.log("Aqu�rio");
							break;
	// Aquario e Peixes						
		case 2:
				if (d <= 18)
					console.log("Aqu�rio");
				else 
                console.log("Peixes");
							break;
	// Peixes e Aries						
		case 3:
				if (d <= 20)
					console.log("Peixes");
				else
                console.log("�ries");
							break;
	// �ries e 						
		case 4:
				if (d <= 20)
					console.log("�ries");
				else
                console.log("Touro");
							break;
		case 5:
				if (d <= 20)
					console.log("Touro");
				else
                console.log("G�meos");
							break;					
		case 6:
				if (d <= 20)
					console.log("G�meos");
				else
                console.log("C�ncer");
							break;
		case 7:
				if (d <= 22)
					console.log("C�ncer");
				else
                console.log("Le�o");
							break;				
		case 8:
				if (d <= 22)
					console.log("Le�o");
				else
                console.log("Virgem");
							break;					
		case 9:
				if (d <= 22)
					console.log("Virgem");
				else
                console.log("Libra");
							break;
		case 10:
				if (d <= 22)
					console.log("Libra");
				else
                console.log("Escorpi�o");
							break;
		case 11:
				if (d <= 21)
					console.log("Escorpi�o");
				else
                console.log("Sagit�rio");
							break;
		case 12:
				if (d <= 21)
					console.log("Sagit�rio");
				else
                console.log("Capric�rnio");
							break;				
		default:
            console.log("M�s Inv�lido");					
		}
		