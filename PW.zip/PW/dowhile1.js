let i = 0
do  {
     i ++
    if (i % 10 <= 0) {
        console.log(i+"-Multiplo de 10");
    }else {
    console.log(i);
    }

} while (i != 100)