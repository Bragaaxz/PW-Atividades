
	for(i=0; i<=100; i++) {
		if (i % 10 <= 0) {
			console.log(i+"-Multiplo de 10");
		}else {
		console.log(i);
		}
	}
