
	
 let codigo = 2
// switch case
	switch (codigo) {
	case 1:
		console.log("Cachorro quente no valor de : R$ 8,00");
	break;
	case 2:
		console.log("Cheeseburguer no valor de : R$ 12,00");
	break;
	case 3:
		console.log("X-salada no valor de : R$ 15,00");
	break;
	case 4:
		console.log("Misto quente no valor de : R$ 11,00");
	break;
	case 5:
		console.log("P�o na chapa no valor de : R$ 6,00");
	break;
	default:
		console.log("N�o temos o c�digo deste produto.");
	}