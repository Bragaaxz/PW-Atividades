soma = 1;
i = 1;
do 	{
    i += 1;
    soma += i;
console.log(soma);  	
} while (i <= 100 ) 