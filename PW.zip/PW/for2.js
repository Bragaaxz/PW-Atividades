
        for (i = 2; i <=200; i+=2) {
            console.log(i);
        	
        }
    