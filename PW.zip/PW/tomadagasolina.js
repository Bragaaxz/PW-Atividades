
	let dis = 20
	let capa = 15
		 let medio = dis/capa
	if ( medio >=10) {
		console.log ( "Econômico, seu gasto médio foi : " + medio);
	}else {
		console.log ("Não econômico, seu gasto médio foi : " + medio);
	}	