
        
         let soma = 1;
        for ( i= 0; i < 100; i++ )	{
            soma += i;
        console.log(soma);  
        }
        