let i=2;
	do {
		console.log(i);
	i +=2;	
    } while  ( i <=200)